/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DASARPEMROGRAMAN;

/**
 *
 * @author Indra Khadra Maulana
 */
public class TUGAS1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    String UP1 =     "PROVINSI JAWA TIMUR";//VARIABLE PROVINSI
    String UP2      = "KOTA PASURUAN";//VARIABLE KOTA
    String Nama     = "Indra Khadra Maulana";
    char Bold       = 'B';
    long NIK;
    NIK             = 3575020304940002L;
    String TempatL  = "PASURUAN";
    byte TanggalL   = 03;
    byte BulanL     = 04;
    short TahunL    = 1994;
    String Gender   = "Laki-Laki";
    String Alamat   = "MANCILAN";
    byte RT         = 007;
    String RW         = "004";
    String Kel_Des  = "Pohjentrek";
    String Kec      = "PURWoREJO";
    String Agama    = "ISLAM";
    String Marital  = "BELUM KAWIN";
    String Kerja    = "PELAJAR/Mahasiswa";
    String Citizen  = "WNI";
    String Exp  = "2017-04-03";
    System.out.println("==================================================================");
    System.out.println("=                      " + UP1 + "                       =");
    System.out.println("=                         " + UP2 + "                         =");
    System.out.println("= Nama              : " + Nama.toUpperCase() + "      Gol. Darah :" + Bold + "    =");
    System.out.println("= NIK               : " + NIK + "                           =");
    System.out.println("= Tempat/Tgl Lahir  : " + TempatL + ", " + TanggalL + "-" + BulanL + "-" + TahunL + "                         =");
    System.out.println("= Jenis Kelamin     : " + Gender + "                                  =");
    System.out.println("= Alamat            : " + Alamat + "                                   =");
    System.out.println("=       RT/RW       : " + RT + "/" + RW + "                                      =");
    System.out.println("=       Kel/Desa    : " + Kel_Des.toUpperCase() + "                                 =");
    System.out.println("=       Kecamatan   : " + Kec.toUpperCase() + "                                  =");
    System.out.println("= Agama             : " + Agama + "                                      =");
    System.out.println("= Status Perkawinan : " + Marital+ "                                =");
    System.out.println("= Pekerjaan         : " + Kerja.toUpperCase() + "                          =");
    System.out.println("= Kewarganegaraan   : " + Citizen + "                                        =");
    System.out.println("= Berlaku hingga    : " + Exp + "                                 =");
    System.out.println("==================================================================");
    long NIM = 201969040063L;
    System.out.println(" NIM            : " + NIM);
    int Tahun = 2019;
    System.out.println(" Tahun Angkatan : " + Tahun);
    
    }
    
}
